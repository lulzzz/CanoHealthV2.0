﻿using System.Web.Mvc;

namespace Kendo.Mvc.Examples.Controllers
{
    public partial class MaskedTextBoxController : Controller
    {
        [Demo]
        public ActionResult Validation()
        {
            return View();
        }
    }
}