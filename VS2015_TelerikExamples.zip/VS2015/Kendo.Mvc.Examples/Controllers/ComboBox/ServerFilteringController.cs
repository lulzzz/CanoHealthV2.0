﻿namespace Kendo.Mvc.Examples.Controllers
{
    using System.Web.Mvc;

    public partial class ComboBoxController : Controller
    {
        [Demo]
        public ActionResult ServerFiltering()
        {
            return View();
        }
    }
}