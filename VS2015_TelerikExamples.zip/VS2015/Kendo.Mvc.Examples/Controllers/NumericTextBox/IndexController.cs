﻿using System.Web.Mvc;

namespace Kendo.Mvc.Examples.Controllers
{
    public partial class NumericTextBoxController : Controller
    {
        [Demo]
        public ActionResult Index()
        {
            return View();
        }
    }
}