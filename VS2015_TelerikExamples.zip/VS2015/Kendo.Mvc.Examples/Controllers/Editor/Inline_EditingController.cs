﻿using System;
using System.Linq;
using System.Web.Mvc;

namespace Kendo.Mvc.Examples.Controllers
{
    public partial class EditorController : Controller
    {
        [Demo]
        public ActionResult Inline_Editing()
        {
            return View();
        }
    }
}