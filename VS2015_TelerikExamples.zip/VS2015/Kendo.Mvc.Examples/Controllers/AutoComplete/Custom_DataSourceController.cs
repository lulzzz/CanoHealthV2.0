﻿namespace Kendo.Mvc.Examples.Controllers
{
    using System.Web.Mvc;

    public partial class AutoCompleteController
    {
        [Demo]
        public ActionResult Custom_DataSource()
        {
            return View();
        }
    }
}