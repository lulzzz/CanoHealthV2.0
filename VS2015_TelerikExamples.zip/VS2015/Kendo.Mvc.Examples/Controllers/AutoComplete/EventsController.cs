﻿namespace Kendo.Mvc.Examples.Controllers
{
    using System.Web.Mvc;

    public partial class AutoCompleteController
    {
        [Demo]
        public ActionResult Events()
        {
            return View();
        }
    }
}