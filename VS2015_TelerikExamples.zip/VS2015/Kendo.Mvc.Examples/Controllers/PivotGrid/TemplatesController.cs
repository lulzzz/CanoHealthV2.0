﻿﻿using Kendo.Mvc.Examples.Models;
using Kendo.Mvc.Extensions;
using Kendo.Mvc.UI;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;

namespace Kendo.Mvc.Examples.Controllers
{
    public partial class PivotGridController : Controller
    {
        [Demo]
        public ActionResult Templates()
        {
            return View();
        }
    }
}
