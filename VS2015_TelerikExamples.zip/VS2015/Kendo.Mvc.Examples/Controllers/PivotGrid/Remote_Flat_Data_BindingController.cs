﻿﻿using System.Web.Mvc;

namespace Kendo.Mvc.Examples.Controllers
{
    public partial class PivotGridController : Controller
    {
        [Demo]
        public ActionResult Remote_Flat_Data_Binding()
        {
            return View();
        }
    }
}
