﻿namespace Kendo.Mvc.Examples.Controllers
{
    using System.Web.Mvc;

    public partial class DropDownListController : Controller
    {
        [Demo]
        public ActionResult Events()
        {
            return View();
        }
    }
}