﻿using System.Web.Mvc;

namespace Kendo.Mvc.Examples.Controllers
{
    public partial class Radial_GaugeController : Controller
    {
        [Demo]
        public ActionResult Scale_Options()
        {
            return View();
        }
    }
}