﻿using System;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Kendo.Mvc.Examples.Controllers
{
    public partial class Range_Bar_ChartsController : Controller
    {
        [Demo]
        public ActionResult Index()
        {
            return View();
        }

    }
}
