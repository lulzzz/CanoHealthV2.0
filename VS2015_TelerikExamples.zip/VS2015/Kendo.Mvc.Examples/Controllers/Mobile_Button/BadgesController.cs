﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Kendo.Mvc.Examples.Controllers
{
    public partial class Mobile_ButtonController : Controller
    {
        public ActionResult Badges()
        {
            return View();
        }        
    }
}
