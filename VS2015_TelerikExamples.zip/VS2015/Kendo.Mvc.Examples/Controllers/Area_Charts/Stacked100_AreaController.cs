﻿using System;
using System.Linq;
using System.Web.Mvc;

namespace Kendo.Mvc.Examples.Controllers
{
    public partial class Area_ChartsController : Controller
    {
        [Demo]
        public ActionResult Stacked100_Area()
        {
            return View();
        }
    }
}