﻿namespace Kendo.Mvc.Examples.Controllers
{
    using System.Web.Mvc;

    public partial class MultiSelectController : Controller
    {
        [Demo]
        public ActionResult ServerFiltering()
        {
            return View();
        }
    }
}