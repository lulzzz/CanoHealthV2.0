﻿using System.Web.Mvc;

namespace Kendo.Mvc.Examples.Controllers
{
    public partial class Linear_GaugeController : Controller
    {
        [Demo]
        public ActionResult Export()
        {
            return View();
        }
    }
}