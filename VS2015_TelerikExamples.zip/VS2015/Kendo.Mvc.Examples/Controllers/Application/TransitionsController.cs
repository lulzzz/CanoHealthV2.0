﻿using System.Web.Mvc;

namespace Kendo.Mvc.Examples.Controllers
{
    public partial class ApplicationController : Controller
    {
        public ActionResult Transitions()
        {
            return View();
        }
    }
}
