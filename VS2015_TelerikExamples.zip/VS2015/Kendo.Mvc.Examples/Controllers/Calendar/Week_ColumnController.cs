﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Kendo.Mvc.Examples.Controllers
{
    public partial class CalendarController : Controller
    {
        //
        // GET: /Week_Column/
        [Demo]
        public ActionResult Week_Column()
        {
            return View();
        }

    }
}
