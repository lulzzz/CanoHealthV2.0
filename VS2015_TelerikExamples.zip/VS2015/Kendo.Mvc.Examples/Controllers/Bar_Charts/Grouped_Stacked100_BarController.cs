﻿using System;
using System.Linq;
using System.Web.Mvc;

namespace Kendo.Mvc.Examples.Controllers
{
    public partial class Bar_ChartsController : Controller
    {
        [Demo]
        public ActionResult Grouped_Stacked100_Bar()
        {
            return View();
        }
    }
}