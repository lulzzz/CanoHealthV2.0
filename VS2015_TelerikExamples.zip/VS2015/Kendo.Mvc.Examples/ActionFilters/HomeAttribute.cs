﻿namespace Kendo.Mvc.Examples.Controllers
{
    public class HomeAttribute : ActionFilterAttributeBase
    {

    }
}