﻿namespace CanoHealth.WebPortal.ViewModels.Account
{
    public class ExternalLoginListViewModel
    {
        public string ReturnUrl { get; set; }
    }
}