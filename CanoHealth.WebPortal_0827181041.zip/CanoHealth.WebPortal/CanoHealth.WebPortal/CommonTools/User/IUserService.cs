﻿namespace CanoHealth.WebPortal.CommonTools.User
{
    public interface IUserService
    {
        string GetUserName();
    }
}
