﻿namespace CanoHealth.WebPortal.CommonTools.Roles
{
    public static class RoleName
    {
        public static string Admin = "ADMIN";
        public static string Biller = "BILLER";
        public static string CallCenter = "CALL CENTER";
    }
}