using System.Data.Entity.Migrations;

namespace CanoHealth.WebPortal.Migrations
{
    public partial class init : DbMigration
    {
        public override void Up()
        {
        }

        public override void Down()
        {
        }
    }
}
