using System;

namespace CanoHealth.WebPortal.CommonTools.CurrentDateTime
{
    public interface ICurrentDateTimeService
    {
        DateTime GetCurrentDateTime();
    }
}