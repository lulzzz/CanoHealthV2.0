namespace CanoHealth.WebPortal.ViewModels
{
    public class OriginalUniqueNameViewModel
    {
        public string OriginalName { get; set; }

        public string UniqueName { get; set; }
    }
}