namespace CanoHealth.WebPortal.Core.Dtos.Npi
{
    public class OtherNamesDto
    {
        public string code { get; set; }

        public string credential { get; set; }

        public string first_name { get; set; }

        public string last_name { get; set; }

        public string middle_name { get; set; }

        public string prefix { get; set; }

        public string type { get; set; }
    }
}