﻿using System;

namespace CanoHealth.WebPortal.Core.Dtos
{
    public class DoctorFileTypeDto
    {
        public Guid DoctorFileTypeId { get; set; }

        public string DoctorFileTypeName { get; set; }
    }
}