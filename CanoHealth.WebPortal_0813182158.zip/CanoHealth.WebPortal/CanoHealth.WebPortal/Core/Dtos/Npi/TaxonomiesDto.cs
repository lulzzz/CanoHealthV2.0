namespace CanoHealth.WebPortal.Core.Dtos.Npi
{
    public class TaxonomiesDto
    {
        public string code { get; set; }

        public string desc { get; set; }

        public string license { get; set; }

        public bool primary { get; set; }

        public string state { get; set; }
    }
}