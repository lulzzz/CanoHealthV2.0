﻿using System;

namespace CanoHealth.WebPortal.Core.Dtos
{
    public class LicenseTypeDto
    {
        public Guid LicenseTypeId { get; set; }

        public string LicenseName { get; set; }
    }
}