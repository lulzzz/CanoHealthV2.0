﻿using CanoHealth.WebPortal.Core.Domain;

namespace CanoHealth.WebPortal.Core.Repositories
{
    public interface IAuditLogReporitory : IRepository<AuditLog>
    {
    }
}
