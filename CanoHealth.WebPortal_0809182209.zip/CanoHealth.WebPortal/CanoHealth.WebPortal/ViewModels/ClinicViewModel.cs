using System;

namespace CanoHealth.WebPortal.ViewModels
{
    public class ClinicViewModel
    {
        public Guid PlaceOfServiceId { get; set; }

        public string PlaceOfServiceName { get; set; }
    }
}