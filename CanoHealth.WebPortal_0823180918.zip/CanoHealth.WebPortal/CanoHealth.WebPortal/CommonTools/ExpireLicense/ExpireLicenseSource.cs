﻿namespace CanoHealth.WebPortal.CommonTools.ExpireLicense
{
    public static class ExpireLicenseSource
    {
        public static string MedicalLicense = "DoctorMedicalLicense";
        public static string LocationLicense = "LocationLicense";
        public static string OutOfNetworkContracts = "OutOfNetworkContracts";
    }
}